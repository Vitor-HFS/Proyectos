package TareaSasteria;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

public class GestionSasteria {

	private HashSet<Empleado> empleados;
	
	public void add() {
		empleados = new HashSet<Empleado>();
	}
	
	
	public boolean addEmpleado(Empleado emple) {
		
		return empleados.add(emple);
		
		
	}
	
	public String buscarTrabajador(String nif) {
		String datos ="";
	
		for (Empleado empleado : empleados) {
			
			if(empleado.getNif().equals(nif)) {
				return empleado.toString();
			}
			
			
		}
		return "No se han encontrado ningun dato sobre ese nif";
		
	}
	
	
	
	//esta bien pero el codigo no quiere ir por culpa de un posible driver de mi ordenador
	
	public ArrayList<Empleado> listar(){
		ArrayList<Empleado> datos = new ArrayList<>(empleados);
		Collections.sort(datos);
		return  datos;
		
	}
	
	
	public int aniadirTrabajo(String codigo, int horas) {
		
		for (Empleado empleado : empleados) {
			
			if(empleado.getCodigo().equals(codigo)) {
				if(empleado instanceof Sastre) {
				
					((Sastre)empleado).setHorasTrabajadas(horas);
					return 1;
					
				}
			
			}
			return 0;
			
			
		}
		
		return -1;
		
	}
	
	
	
public int aniadirVenta(String codigo, int ventas) {
		
		for (Empleado empleado : empleados) {
			
			if(empleado.getCodigo().equals(codigo)) {
				if(empleado instanceof Vendedor) {
				
					((Vendedor)empleado).incrementarVentas(ventas);;
					return 1;
					
				}
			
			}
			return 0;
			
			
		}
		
		return -1;
		
	}
	
	
public int calcularSueldo(String nif) {
	int sueldo=0;
	for (Empleado empleado : empleados) {
		
		if(empleado.getNif().equals(nif)) {
			sueldo+=empleado.getSueldoBase();
		}
		
		
		
	}
	
	return sueldo;
	
}



	
}
