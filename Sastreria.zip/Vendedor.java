package TareaSasteria;

public class Vendedor extends Empleado{

	private String turno;
	private int comision;
	private double numeroVentas;
	
	
	
	public Vendedor(String nif, String nombre, String apellidos, String codigo, int sueldoBase, String turno,
			int comision, double numeroVentas) {
		super(nif, nombre, apellidos, codigo, sueldoBase);
		this.turno = turno;
		this.comision = comision;
		this.numeroVentas = numeroVentas;
	}



	@Override
	public double calcularSueldo() {
		
		return ((comision*numeroVentas)/100)+getSueldoBase();
	}
	
	
	public void incrementarVentas(int numero) {
		
	numeroVentas+=numero;
			
	}
	
	
	
	
}
