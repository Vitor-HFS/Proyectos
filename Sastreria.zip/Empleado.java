package TareaSasteria;

public abstract class Empleado extends Persona{

	private String codigo;
	private double sueldoBase;
	
	public Empleado(String nif, String nombre, String apellidos, String codigo, double sueldoBase) {
		super(nif, nombre, apellidos);
		this.codigo = codigo;
		this.sueldoBase = sueldoBase;
	}
	
	
	
	public String getCodigo() {
		return codigo;
	}



	public double getSueldoBase() {
		return sueldoBase;
	}



	public abstract double calcularSueldo();
	
	
	public int compareTo(Empleado emple) {
		return this.codigo.compareTo(emple.getCodigo());

	}
	
}
