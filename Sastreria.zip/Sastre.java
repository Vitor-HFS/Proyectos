package TareaSasteria;

public class Sastre extends Empleado{

	private int precoHora;
	private int horasTrabajadas;
	
	
	
	public Sastre(String nif, String nombre, String apellidos, String codigo, int sueldoBase, int precoHora,
			int horasTrabajadas) {
		super(nif, nombre, apellidos, codigo, sueldoBase);
		this.precoHora = precoHora;
		this.horasTrabajadas = horasTrabajadas;
	}



	public void setPrecoHora(int precoHora) {
		this.precoHora = precoHora;
	}



	public void setHorasTrabajadas(int horasTrabajadas) {
		this.horasTrabajadas = horasTrabajadas;
	}



	@Override
	public double calcularSueldo() {
		
		return (horasTrabajadas*precoHora)/getSueldoBase();
	}
	
	
	
	
	
	
}
